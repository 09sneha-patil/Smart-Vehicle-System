import { useEffect, useState, useMemo } from 'react';
import { TopBar } from './components/TopBar';
import { Sidebar } from './components/Sidebar';
import { KPICards } from './components/KPICards';
import { AnalyticsSection } from './components/AnalyticsSection';
import { SmartAlerts } from './components/SmartAlerts';
import { TripTable } from './components/TripTable';
import { LiveTracking } from './components/LiveTracking';
import { OverviewMap } from './components/OverviewMap';
import { FleetManagement } from './components/FleetManagement';
import { Settings } from './components/Settings';
import { Reports } from './components/Reports';
import { motion, AnimatePresence } from 'framer-motion';

const API_BASE = 'http://localhost:5000';

function App() {
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({
    in_progress: false,
    duration: "00:00",
    alerts: 0,
    score: 100,
    last_event: "None",
    active_module: null,
    alert_active: false,
    alert_text: ""
  });
  const [alertHistory, setAlertHistory] = useState<any[]>([]);

  const [routeState, setRouteState] = useState<{
    startCoords: [number, number] | null;
    endCoords: [number, number] | null;
    routeLine: [number, number][];
  }>({
    startCoords: null,
    endCoords: null,
    routeLine: []
  });
  const [currentLocation, setCurrentLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setCurrentLocation([position.coords.latitude, position.coords.longitude]);
        },
        (error) => {
          console.warn("Location permission denied or unavailable", error);
        }
      );
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      fetch(`${API_BASE}/api/stats`)
        .then(res => res.json())
        .then(data => setStats(data))
        .catch(err => console.error("Error fetching stats", err));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (stats.alert_active && stats.alert_text) {
      setAlertHistory(prev => {
        // Prevent duplicate consecutive alerts
        if (prev.length > 0 && prev[0].title === stats.alert_text) return prev;
        
        const newAlert = {
          id: Date.now(),
          title: stats.alert_text,
          vehicle: 'V-CURRENT',
          time: new Date().toLocaleTimeString(),
          type: 'warning',
          icon: 'AlertTriangle',
          color: 'text-rose-400',
          bg: 'bg-rose-500/10',
          border: 'border-rose-500/20',
          glow: 'glow-danger'
        };
        return [newAlert, ...prev].slice(0, 50); // keep last 50
      });
    }
  }, [stats.alert_active, stats.alert_text]);

  useEffect(() => {
    fetch(`${API_BASE}/api/trips`)
      .then(res => res.json())
      .then(trips => {
        const loadedAlerts: any[] = [];
        // Extract alerts from historical events (reverse-chronological order)
        [...trips].reverse().forEach((trip: any) => {
          if (trip.events) {
            [...trip.events].reverse().forEach((evt: any) => {
              if (evt.event.includes("Alert")) {
                loadedAlerts.push({
                  id: Math.random(),
                  title: evt.event === "Drowsiness Alert" ? "WAKE UP!" : "OBSTACLE AHEAD!",
                  vehicle: 'V-CURRENT',
                  time: evt.time,
                  type: 'warning',
                  icon: 'AlertTriangle',
                  color: 'text-rose-400',
                  bg: 'bg-rose-500/10',
                  border: 'border-rose-500/20',
                  glow: 'glow-danger'
                });
              }
            });
          }
        });
        setAlertHistory(loadedAlerts.slice(0, 50));
      })
      .catch(err => console.error("Error pre-populating historical alerts", err));
  }, []);

  const handleStartTrip = async () => {
    await fetch(`${API_BASE}/api/trip/start`, { method: 'POST' });
    await fetch(`${API_BASE}/api/module/drowsiness/start`, { method: 'POST' });
  };
  const handleStopTrip = () => fetch(`${API_BASE}/api/trip/stop`, { method: 'POST' });
  const startModule = (module: string) => fetch(`${API_BASE}/api/module/${module}/start`, { method: 'POST' });
  const stopModule = () => fetch(`${API_BASE}/api/module/stop`, { method: 'POST' });

  const [streamTimestamp, setStreamTimestamp] = useState(Date.now());

  useEffect(() => {
    if (stats.active_module) {
      setStreamTimestamp(Date.now());
    }
  }, [stats.active_module]);

  // Memoize the camera feed URL to avoid re-fetching the stream every 1 second when stats update
  const videoFeedUrl = useMemo(() => {
    return stats.active_module ? `${API_BASE}/video_feed?m=${stats.active_module}&t=${streamTimestamp}` : undefined;
  }, [stats.active_module, streamTimestamp]);

  const renderContent = () => {
    switch (activeTab) {
      case 'overview':
        return (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
            <KPICards stats={stats} />
            
            {/* Split View: Map (Left) & Camera Feed (Right) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
              {/* Map View */}
              <div className="glass-card overflow-hidden rounded-2xl h-[400px] lg:h-[500px]">
                <OverviewMap currentLocation={currentLocation} routeState={routeState} />
              </div>

              {/* Live Camera Feed */}
              <div className={`relative h-[400px] lg:h-[500px] w-full overflow-hidden rounded-2xl glass-card flex items-center justify-center border-2 transition-colors duration-300 ${stats.alert_active ? 'border-rose-500 glow-danger' : 'border-white/10'}`}>
                {stats.active_module ? (
                  <img 
                    src={videoFeedUrl} 
                    alt="Live Camera Feed" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-white/50">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mb-4 border border-white/10">
                      <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <p>No Active Module</p>
                    <p className="text-sm mt-2 text-center max-w-sm">Select "Drowsiness" or "Obstacle" to view live camera feed and activate AI tracking.</p>
                  </div>
                )}
                {stats.alert_active && (
                  <div className="absolute inset-0 bg-rose-500/20 flex items-center justify-center pointer-events-none">
                    <h1 className="text-5xl font-black text-rose-500 tracking-widest text-glow drop-shadow-2xl">{stats.alert_text}</h1>
                  </div>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6 mb-6">
              <div className="xl:col-span-2">
                <AnalyticsSection stats={stats} />
              </div>
              <div className="xl:col-span-1">
                <SmartAlerts alertHistory={alertHistory} onClear={() => setAlertHistory([])} />
              </div>
            </div>

            <TripTable stats={stats} />
          </motion.div>
        );
      case 'tracking':
        return <LiveTracking key="tracking" routeState={routeState} setRouteState={setRouteState} setActiveTab={setActiveTab} />;
      case 'analytics':
        return (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-6">
            <h3 className="text-2xl font-bold text-white mb-4">Detailed Driver Analytics</h3>
            <AnalyticsSection stats={stats} />
            {/* Can add more charts here if needed */}
          </motion.div>
        );
      case 'trips':
        return (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-full">
            <TripTable stats={stats} />
          </motion.div>
        );
      case 'alerts':
        return (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="h-[800px] max-w-3xl mx-auto">
            <SmartAlerts alertHistory={alertHistory} onClear={() => setAlertHistory([])} />
          </motion.div>
        );
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      case 'fleet':
        return <FleetManagement />;
      default:
        return (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col items-center justify-center h-96 text-white/50 glass-card">
            <h3 className="text-2xl font-bold text-white mb-2">Coming Soon</h3>
            <p>This module is currently under development for the enterprise tier.</p>
          </motion.div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background text-white flex flex-col font-sans">
      <div className="fixed inset-0 z-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] bg-violet-500/10 rounded-full blur-[150px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-500/5 rounded-full blur-[150px]" />
      </div>

      <TopBar />

      <div className="flex flex-1 relative z-10">
        <div className="sticky top-0 h-screen">
          <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} alertCount={alertHistory.length} />
        </div>
        
        <main className="flex-1 p-6 md:p-8 w-full min-w-0">
          <div className="max-w-[1600px] mx-auto">
            
            {/* Always visible top control header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4">
              <div>
                <h2 className="text-3xl font-bold tracking-tight text-glow mb-2 capitalize">{activeTab.replace('-', ' ')}</h2>
                <p className="text-white/50">Status: {stats.in_progress ? "● Trip Active" : "● System Ready"} | Last Event: {stats.last_event}</p>
              </div>
              
              <div className="flex flex-wrap gap-3">
                {!stats.in_progress ? (
                  <button onClick={handleStartTrip} className="px-4 py-2 rounded-xl bg-emerald-500 text-white border border-emerald-400/50 text-sm font-bold hover:bg-emerald-400 glow-success transition-all">
                    START TRIP
                  </button>
                ) : (
                  <button onClick={handleStopTrip} className="px-4 py-2 rounded-xl bg-rose-500 text-white border border-rose-400/50 text-sm font-bold hover:bg-rose-400 glow-danger transition-all">
                    STOP TRIP
                  </button>
                )}
                
                <button 
                  onClick={() => startModule('drowsiness')} 
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${stats.active_module === 'drowsiness' ? 'bg-cyan-500 text-white glow-cyan' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                >
                  DROWSINESS
                </button>
                
                <button 
                  onClick={() => startModule('obstacle')} 
                  className={`px-4 py-2 rounded-xl text-sm font-bold transition-all ${stats.active_module === 'obstacle' ? 'bg-amber-500 text-white glow-warning' : 'bg-white/5 border border-white/10 hover:bg-white/10'}`}
                >
                  OBSTACLE
                </button>
                
                {stats.active_module && (
                  <button onClick={stopModule} className="px-4 py-2 rounded-xl bg-white/10 text-white border border-white/20 text-sm font-bold hover:bg-white/20 transition-all">
                    STOP MODULE
                  </button>
                )}
              </div>
            </div>

            {/* Dynamic Content Area */}
            <AnimatePresence mode="wait">
              {renderContent()}
            </AnimatePresence>
            
          </div>
        </main>
      </div>
    </div>
  );
}

export default App;
