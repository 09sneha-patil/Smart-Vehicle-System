import { motion } from 'framer-motion';
import { AlertOctagon, Gauge, Clock, CheckCircle2, AlertTriangle } from 'lucide-react';
import { clsx } from 'clsx';

const ICON_MAP: Record<string, any> = {
  'AlertTriangle': AlertTriangle,
  'AlertOctagon': AlertOctagon,
  'Gauge': Gauge,
  'Clock': Clock
};

export function SmartAlerts({ alertHistory = [], onClear }: { alertHistory?: any[], onClear?: () => void }) {
  return (
    <div className="glass-card flex flex-col h-[500px] w-full">
      <div className="p-5 border-b border-white/10 flex justify-between items-center">
        <h3 className="text-lg font-semibold text-white">Smart Alerts</h3>
        <button 
          onClick={onClear} 
          className="text-xs text-cyan-400 hover:text-cyan-300 transition-colors"
        >
          Mark all read
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {alertHistory.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-white/40">
            <CheckCircle2 size={32} className="mb-2 text-emerald-500/50" />
            <p className="text-sm">No recent alerts</p>
          </div>
        ) : alertHistory.map((alert, index) => {
          const Icon = ICON_MAP[alert.icon] || AlertTriangle;
          return (
            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: Math.min(index * 0.1, 0.5) }}
              key={alert.id}
              className={clsx(
                "p-4 rounded-xl border backdrop-blur-md flex gap-4 items-start group hover:-translate-y-0.5 transition-transform cursor-pointer animate-pulse-once",
                alert.bg, alert.border
              )}
            >
              <div className={clsx("p-2 rounded-lg bg-black/20", alert.glow)}>
                <Icon size={18} className={alert.color} />
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex justify-between items-start mb-1">
                  <h4 className="text-white text-sm font-medium truncate pr-2">{alert.title}</h4>
                  <span className="text-[10px] text-white/40 whitespace-nowrap">{alert.time}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-white/60 bg-black/20 px-2 py-0.5 rounded border border-white/5">
                    {alert.vehicle}
                  </span>
                </div>
              </div>
            </motion.div>
          )
        })}
      </div>
    </div>
  );
}
