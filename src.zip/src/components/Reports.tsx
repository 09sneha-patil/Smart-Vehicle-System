import { motion } from 'framer-motion';
import { FileText, Download } from 'lucide-react';

export function Reports() {
  const reportsList = [
    { name: 'Weekly Safety Summary', date: 'Oct 14, 2026', size: '2.4 MB' },
    { name: 'Fleet Utilization Report', date: 'Oct 12, 2026', size: '1.8 MB' },
    { name: 'Incident Logs (Q3)', date: 'Oct 01, 2026', size: '5.1 MB' },
    { name: 'Driver Behavior Analysis', date: 'Sep 28, 2026', size: '3.2 MB' },
  ];

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-2xl font-bold text-white">System Reports</h3>
        <button className="px-4 py-2 bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-xl font-medium hover:bg-cyan-500/30 transition-colors">
          Generate New Report
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {reportsList.map((report, idx) => (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: idx * 0.1 }}
            key={idx} 
            className="glass-card p-6 border border-white/10 hover:border-cyan-500/30 transition-colors group flex flex-col"
          >
            <div className="w-12 h-12 bg-white/5 rounded-xl border border-white/10 flex items-center justify-center mb-4 group-hover:bg-cyan-500/10 group-hover:text-cyan-400 transition-colors">
              <FileText className="text-white/50 group-hover:text-cyan-400 transition-colors" />
            </div>
            <h4 className="text-white font-medium mb-1 line-clamp-1">{report.name}</h4>
            <div className="text-white/40 text-xs flex justify-between mb-6">
              <span>{report.date}</span>
              <span>{report.size}</span>
            </div>
            
            <button className="mt-auto w-full py-2 flex items-center justify-center gap-2 text-sm bg-white/5 text-white/70 rounded-lg hover:bg-white/10 hover:text-white transition-colors border border-white/5">
              <Download size={14} /> Download PDF
            </button>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
