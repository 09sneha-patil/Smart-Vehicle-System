import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Car, Battery, Wifi, Navigation, Plus, X, Trash2, Loader2 } from 'lucide-react';

const API_BASE = 'http://localhost:5000';

interface Vehicle {
  id: string;
  model: string;
  status: string;
  battery: string;
  signal: string;
  location: string;
}

const STATUS_OPTIONS = ['Active', 'Idle', 'Charging', 'Maintenance'];
const SIGNAL_OPTIONS = ['Strong', 'Good', 'Weak'];

export function FleetManagement() {
  const [fleet, setFleet] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState<Omit<Vehicle, 'id'>>({
    model: '', status: 'Active', battery: '', signal: 'Strong', location: ''
  });

  const fetchFleet = async () => {
    try {
      const res = await fetch(`${API_BASE}/api/fleet`);
      const data = await res.json();
      setFleet(data);
    } catch (e) {
      console.error('Failed to load fleet', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchFleet(); }, []);

  const handleAdd = async () => {
    if (!form.model || !form.location || !form.battery) return;
    setSaving(true);
    try {
      await fetch(`${API_BASE}/api/fleet`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form)
      });
      setShowModal(false);
      setForm({ model: '', status: 'Active', battery: '', signal: 'Strong', location: '' });
      fetchFleet();
    } catch (e) {
      console.error('Failed to add vehicle', e);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await fetch(`${API_BASE}/api/fleet/${id}`, { method: 'DELETE' });
      setFleet(prev => prev.filter(v => v.id !== id));
    } catch (e) {
      console.error('Failed to delete vehicle', e);
    }
  };

  const statusStyle = (status: string) => {
    switch (status) {
      case 'Active': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
      case 'Charging': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'Maintenance': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      default: return 'bg-white/10 text-white/70 border-white/20';
    }
  };

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <h3 className="text-2xl font-bold text-white flex items-center gap-2">
          <Car className="text-cyan-400" /> Fleet Management
        </h3>
        <div className="flex items-center gap-4">
          <div className="bg-white/5 border border-white/10 px-4 py-2 rounded-xl text-sm font-medium text-white/70">
            Total: <span className="text-white font-bold">{fleet.length}</span>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500 text-white font-bold hover:bg-cyan-400 glow-cyan transition-all"
          >
            <Plus size={18} /> Add Vehicle
          </button>
        </div>
      </div>

      {/* Fleet Grid */}
      {loading ? (
        <div className="flex justify-center py-20 text-white/50">
          <Loader2 className="animate-spin mr-2" /> Loading fleet...
        </div>
      ) : fleet.length === 0 ? (
        <div className="glass-card p-12 text-center text-white/40">
          <Car size={48} className="mx-auto mb-4 opacity-30" />
          <p className="text-lg">No vehicles added yet.</p>
          <p className="text-sm mt-1">Click "Add Vehicle" to register your first vehicle.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {fleet.map((vehicle, idx) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: idx * 0.05 }}
              key={vehicle.id}
              className="glass-card p-6 border border-white/10 hover:border-cyan-500/30 transition-colors group"
            >
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h4 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">{vehicle.id}</h4>
                  <p className="text-sm text-white/50">{vehicle.model}</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className={`px-2.5 py-1 text-xs font-medium rounded-full border ${statusStyle(vehicle.status)}`}>
                    {vehicle.status}
                  </span>
                  <button
                    onClick={() => handleDelete(vehicle.id)}
                    className="p-1 rounded text-white/30 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
                    title="Remove Vehicle"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>

              <div className="space-y-3 mt-6">
                <div className="flex justify-between items-center text-sm">
                  <span className="text-white/50 flex items-center gap-2"><Battery size={16} /> Battery</span>
                  <span className="text-white font-medium">{vehicle.battery}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-white/50 flex items-center gap-2"><Wifi size={16} /> Signal</span>
                  <span className="text-white font-medium">{vehicle.signal}</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                  <span className="text-white/50 flex items-center gap-2"><Navigation size={16} /> Location</span>
                  <span className="text-white font-medium">{vehicle.location}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Add Vehicle Modal */}
      <AnimatePresence>
        {showModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
            onClick={(e) => e.target === e.currentTarget && setShowModal(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="glass-card p-8 w-full max-w-md mx-4 border border-white/20"
            >
              <div className="flex justify-between items-center mb-6">
                <h4 className="text-xl font-bold text-white">Add New Vehicle</h4>
                <button onClick={() => setShowModal(false)} className="text-white/50 hover:text-white transition-colors">
                  <X size={20} />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-1">Vehicle Model *</label>
                  <input
                    type="text"
                    placeholder="e.g. Tesla Model 3"
                    value={form.model}
                    onChange={e => setForm(f => ({ ...f, model: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-1">Current Location *</label>
                  <input
                    type="text"
                    placeholder="e.g. Downtown, Depot A"
                    value={form.location}
                    onChange={e => setForm(f => ({ ...f, location: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-white/70 mb-1">Battery Level *</label>
                  <input
                    type="text"
                    placeholder="e.g. 85%"
                    value={form.battery}
                    onChange={e => setForm(f => ({ ...f, battery: e.target.value }))}
                    className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white placeholder-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-white/70 mb-1">Status</label>
                    <select
                      value={form.status}
                      onChange={e => setForm(f => ({ ...f, status: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-cyan-500/50 transition-all"
                    >
                      {STATUS_OPTIONS.map(s => <option key={s} value={s} className="bg-gray-900">{s}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-white/70 mb-1">Signal</label>
                    <select
                      value={form.signal}
                      onChange={e => setForm(f => ({ ...f, signal: e.target.value }))}
                      className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-cyan-500/50 transition-all"
                    >
                      {SIGNAL_OPTIONS.map(s => <option key={s} value={s} className="bg-gray-900">{s}</option>)}
                    </select>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button onClick={() => setShowModal(false)} className="flex-1 py-3 rounded-xl bg-white/5 text-white font-medium hover:bg-white/10 transition-colors border border-white/10">
                  Cancel
                </button>
                <button
                  onClick={handleAdd}
                  disabled={saving || !form.model || !form.location || !form.battery}
                  className="flex-1 py-3 rounded-xl bg-cyan-500 text-white font-bold hover:bg-cyan-400 glow-cyan transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {saving ? <Loader2 size={18} className="animate-spin" /> : <Plus size={18} />}
                  {saving ? 'Saving...' : 'Add Vehicle'}
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
