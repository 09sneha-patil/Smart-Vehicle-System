import { Search, Bell, CarFront } from 'lucide-react';
import { motion } from 'framer-motion';

export function TopBar() {
  return (
    <motion.header 
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="h-20 w-full glass-panel border-b border-white/10 flex items-center justify-between px-6 z-50 relative"
    >
      {/* Left: Logo */}
      <div className="flex items-center gap-4">
        <div className="w-10 h-10 rounded-xl bg-accent-gradient p-[1px] glow-cyan">
          <div className="w-full h-full bg-background rounded-xl flex items-center justify-center">
            <CarFront className="text-cyan-400" size={24} />
          </div>
        </div>
        <div className="flex flex-col">
          <h1 className="text-xl font-bold tracking-wide text-white text-glow">SmartDrive</h1>
          <span className="text-xs text-white/50 tracking-wider uppercase">Vehicle Intelligence Platform</span>
        </div>
      </div>

      {/* Center: Search */}
      <div className="flex-1 max-w-xl mx-8">
        <div className="relative group">
          <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-white/40 group-focus-within:text-cyan-400 transition-colors" />
          </div>
          <input
            type="text"
            className="block w-full pl-11 pr-16 py-2.5 glass-card bg-white/5 border-white/10 text-white placeholder-white/30 rounded-xl focus:outline-none focus:ring-1 focus:ring-cyan-500/50 transition-all shadow-inner"
            placeholder="Search vehicles, routes, or drivers..."
          />
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
            <span className="text-white/30 text-xs border border-white/10 px-2 py-1 rounded-md bg-white/5">⌘K</span>
          </div>
        </div>
      </div>

      {/* Right: Actions */}
      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="text-xs text-emerald-400 font-medium">System Online</span>
        </div>

        <button className="relative p-2 rounded-xl hover:bg-white/5 transition-colors group">
          <Bell className="text-white/70 group-hover:text-white transition-colors" size={20} />
          <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-rose-500 border border-background"></span>
        </button>

        <div className="flex items-center gap-3 pl-4 border-l border-white/10 cursor-pointer group">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 font-bold">
            SP
          </div>
          <div className="hidden md:block text-sm">
            <p className="font-medium text-white">Sneha Patil</p>
            <p className="text-white/50 text-xs">Student</p>
          </div>
        </div>
      </div>
    </motion.header>
  );
}
