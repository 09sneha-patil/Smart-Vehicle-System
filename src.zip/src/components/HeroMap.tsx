import { motion } from 'framer-motion';
import { Navigation, Wifi } from 'lucide-react';

export function HeroMap() {
  return (
    <motion.div 
      initial={{ scale: 0.95, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      className="glass-card relative h-[400px] lg:h-[500px] w-full mb-6 overflow-hidden flex items-center justify-center group"
    >
      {/* Simulated dark map background using a pattern */}
      <div className="absolute inset-0 opacity-20 pointer-events-none" style={{
        backgroundImage: `radial-gradient(circle at 2px 2px, rgba(255,255,255,0.15) 1px, transparent 0)`,
        backgroundSize: '32px 32px'
      }} />
      
      <div className="absolute inset-0 bg-gradient-to-t from-background via-transparent to-background/50 z-0" />

      {/* Simulated Route Trails */}
      <svg className="absolute inset-0 w-full h-full z-10 opacity-30" preserveAspectRatio="none">
        <motion.path
          d="M 100,300 Q 300,400 500,200 T 900,250"
          fill="transparent"
          stroke="#06b6d4"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2, ease: "easeInOut" }}
        />
        <motion.path
          d="M 200,100 Q 400,150 600,350 T 1000,100"
          fill="transparent"
          stroke="#8b5cf6"
          strokeWidth="2"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 2.5, ease: "easeInOut" }}
        />
      </svg>

      {/* Animated Vehicle Markers */}
      <motion.div 
        animate={{ 
          x: [100, 500, 900],
          y: [300, 200, 250]
        }}
        transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        className="absolute z-20 flex flex-col items-center"
      >
        <div className="w-8 h-8 bg-cyan-500/20 rounded-full flex items-center justify-center glow-cyan relative">
          <div className="absolute inset-0 rounded-full bg-cyan-500 animate-ping opacity-20"></div>
          <Navigation size={16} className="text-cyan-400 rotate-45" />
        </div>
        
        {/* Hover Mini Stats */}
        <div className="opacity-0 group-hover:opacity-100 transition-opacity absolute top-10 w-32 bg-black/80 backdrop-blur-md border border-white/10 rounded-lg p-2 text-xs shadow-xl">
          <div className="flex justify-between items-center mb-1">
            <span className="text-white/70">Vehicle</span>
            <span className="text-white font-bold">V-402</span>
          </div>
          <div className="flex justify-between items-center mb-1">
            <span className="text-white/70">Speed</span>
            <span className="text-cyan-400 font-bold">68 km/h</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-white/70">Status</span>
            <div className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
              <span className="text-emerald-400">Active</span>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Central Overlay Info */}
      <div className="absolute bottom-6 right-6 z-30 glass-card p-4 border border-white/10 flex items-center gap-4">
        <div className="p-2 bg-emerald-500/20 rounded-lg glow-success">
          <Wifi size={20} className="text-emerald-400" />
        </div>
        <div>
          <div className="text-sm font-medium text-white">Live Fleet Sync</div>
          <div className="text-xs text-white/50">Updated 2s ago</div>
        </div>
      </div>
    </motion.div>
  );
}
