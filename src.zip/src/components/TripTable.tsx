import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Search, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';
import { clsx } from 'clsx';

const API_BASE = 'http://localhost:5000';
const PAGE_SIZE = 5;

const getStatusStyle = (status: string) => {
  switch (status) {
    case 'Active': return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    case 'Completed': return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
    case 'Warning': return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    case 'Critical': return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
    default: return 'bg-white/10 text-white/70 border-white/20';
  }
};

const getScoreStyle = (score: number) => {
  if (score >= 90) return 'text-emerald-400';
  if (score >= 80) return 'text-amber-400';
  return 'text-rose-400';
};

function formatStatus(score: number) {
  if (score >= 90) return 'Completed';
  if (score >= 70) return 'Warning';
  return 'Critical';
}

export function TripTable({ stats }: { stats?: any }) {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => {
    fetch(`${API_BASE}/api/trips`)
      .then(res => res.json())
      .then(data => setHistory([...data].reverse()))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [stats?.in_progress]); // Refresh when a trip ends

  // If a trip is active prepend it
  const activeTrip = stats?.in_progress ? [{
    id: 'TRP-LIVE',
    date: new Date().toLocaleString(),
    vehicle: 'V-CURRENT',
    route: 'Active Tracking',
    distance: 'Live',
    speed: 'Live',
    score: stats.score || 100,
    status: 'Active'
  }] : [];

  // Map history logs to display rows
  const historyRows = history.map((t: any, idx: number) => ({
    id: `TRP-${String(history.length - idx).padStart(4, '0')}`,
    date: t.date,
    vehicle: 'V-CURRENT',
    route: `${t.drowsiness_alerts} drowsy / ${t.obstacle_alerts} obstacles`,
    distance: `${t.duration_minutes} min trip`,
    speed: `Score: ${t.safety_score}`,
    score: t.safety_score,
    status: formatStatus(t.safety_score)
  }));

  const allRows = [...activeTrip, ...historyRows];

  // Search
  const filtered = allRows.filter(t =>
    search === '' ||
    t.id.toLowerCase().includes(search.toLowerCase()) ||
    t.route.toLowerCase().includes(search.toLowerCase()) ||
    t.date.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const pageRows = filtered.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const pageNumbers = Array.from({ length: Math.min(totalPages, 5) }, (_, i) => i + 1);

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="glass-card overflow-hidden flex flex-col"
    >
      <div className="p-5 border-b border-white/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <h3 className="text-lg font-semibold text-white">
          Trip History <span className="text-xs text-white/40 font-normal ml-1">(Last 30 days)</span>
        </h3>
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="relative flex-1 sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
            <input
              type="text"
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search trips..."
              className="w-full bg-white/5 border border-white/10 rounded-lg pl-9 pr-4 py-2 text-sm text-white placeholder-white/30 focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
            />
          </div>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-white/70">
          <thead className="text-xs uppercase bg-black/20 text-white/50 sticky top-0 z-10 backdrop-blur-md">
            <tr>
              <th className="px-6 py-4 font-medium tracking-wider">Trip ID</th>
              <th className="px-6 py-4 font-medium tracking-wider">Date</th>
              <th className="px-6 py-4 font-medium tracking-wider">Vehicle</th>
              <th className="px-6 py-4 font-medium tracking-wider">Details</th>
              <th className="px-6 py-4 font-medium tracking-wider">Duration</th>
              <th className="px-6 py-4 font-medium tracking-wider">Score</th>
              <th className="px-6 py-4 font-medium tracking-wider">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {loading ? (
              <tr>
                <td colSpan={7} className="px-6 py-10 text-center">
                  <Loader2 className="animate-spin mx-auto text-cyan-400" />
                </td>
              </tr>
            ) : pageRows.length === 0 ? (
              <tr>
                <td colSpan={7} className="px-6 py-10 text-center text-white/50">
                  {search ? 'No trips match your search.' : 'No trips in the last 30 days. Start a trip to record history.'}
                </td>
              </tr>
            ) : pageRows.map((trip) => (
              <tr key={trip.id} className="hover:bg-white/[0.02] transition-colors group">
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="text-white group-hover:text-cyan-400 transition-colors font-medium">{trip.id}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-white/60 text-xs">{trip.date}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                    <span className="font-medium text-white">{trip.vehicle}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-white/70">{trip.route}</td>
                <td className="px-6 py-4 whitespace-nowrap text-white/90">{trip.distance}</td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={clsx('font-bold', getScoreStyle(trip.score))}>{trip.score}</span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={clsx('px-2.5 py-1 text-xs font-medium rounded-full border', getStatusStyle(trip.status))}>
                    {trip.status}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      <div className="p-4 border-t border-white/10 flex items-center justify-between text-sm text-white/50 bg-black/10">
        <div>
          Showing <span className="text-white font-medium">{pageRows.length}</span> of{' '}
          <span className="text-white font-medium">{filtered.length}</span> trips
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-1 rounded hover:bg-white/10 transition-colors disabled:opacity-30"
          >
            <ChevronLeft size={18} />
          </button>
          <div className="flex items-center gap-1">
            {pageNumbers.map(n => (
              <button
                key={n}
                onClick={() => setPage(n)}
                className={clsx(
                  'w-8 h-8 rounded flex items-center justify-center font-medium transition-colors',
                  n === currentPage
                    ? 'bg-cyan-500/20 text-cyan-400 border border-cyan-500/30'
                    : 'hover:bg-white/10 text-white'
                )}
              >
                {n}
              </button>
            ))}
          </div>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-1 rounded hover:bg-white/10 transition-colors disabled:opacity-30"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
