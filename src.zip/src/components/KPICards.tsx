import { motion } from 'framer-motion';
import { Area, AreaChart, ResponsiveContainer } from 'recharts';
import { Car, ShieldAlert, Zap, Clock } from 'lucide-react';

const generateSparklineData = () => Array.from({ length: 10 }, () => ({ value: Math.floor(Math.random() * 100) + 20 }));

export function KPICards({ stats }: { stats: any }) {
  const kpis = [
    {
      title: 'Trip Duration',
      value: stats?.duration || '00:00',
      change: 'Active',
      isPositive: true,
      icon: Clock,
      color: '#06b6d4', // Cyan
      data: generateSparklineData()
    },
    {
      title: 'Safety Score',
      value: stats?.score !== undefined ? stats.score : '100',
      change: 'Current',
      isPositive: stats?.score >= 80,
      icon: ShieldAlert,
      color: stats?.score >= 80 ? '#10b981' : (stats?.score >= 50 ? '#f59e0b' : '#ef4444'),
      data: generateSparklineData()
    },
    {
      title: 'Total Alerts',
      value: stats?.alerts !== undefined ? stats.alerts : '0',
      change: 'Trip',
      isPositive: stats?.alerts === 0,
      icon: Zap,
      color: '#f59e0b', // Amber
      data: generateSparklineData()
    },
    {
      title: 'Active Vehicles',
      value: '1',
      unit: '',
      change: 'Local',
      isPositive: true,
      icon: Car,
      color: '#8b5cf6', // Violet
      data: generateSparklineData()
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {kpis.map((kpi, index) => {
        const Icon = kpi.icon;
        return (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: index * 0.1 }}
            key={index}
            className="group relative glass-card p-5 overflow-hidden hover:-translate-y-1 transition-transform duration-300"
          >
            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-[100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
            
            <div className="relative z-10 flex justify-between items-start">
              <div>
                <p className="text-white/50 text-sm font-medium mb-1">{kpi.title}</p>
                <div className="flex items-baseline gap-1">
                  <h3 className="text-3xl font-bold text-white tracking-tight">{kpi.value}</h3>
                  {kpi.unit && <span className="text-white/50 text-sm">{kpi.unit}</span>}
                </div>
                <div className={`text-xs mt-2 font-medium ${kpi.isPositive ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {kpi.change}
                </div>
              </div>
              
              <div className="p-3 rounded-xl bg-white/5 border border-white/10" style={{ boxShadow: `0 0 20px ${kpi.color}20` }}>
                <Icon size={20} style={{ color: kpi.color }} />
              </div>
            </div>

            <div className="h-12 w-full mt-4 opacity-50 group-hover:opacity-100 transition-opacity">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={kpi.data}>
                  <defs>
                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={kpi.color} stopOpacity={0.3}/>
                      <stop offset="95%" stopColor={kpi.color} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <Area 
                    type="monotone" 
                    dataKey="value" 
                    stroke={kpi.color} 
                    fillOpacity={1} 
                    fill={`url(#gradient-${index})`} 
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        )
      })}
    </div>
  );
}
