import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MapPin, Navigation, Map as MapIcon, Loader2, Crosshair, Search, RotateCcw, XCircle } from 'lucide-react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet icon paths
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

// A component to automatically fit bounds to the route
function MapUpdater({ route, start, end }: { route: any, start: any, end: any }) {
  const map = useMap();
  useEffect(() => {
    if (route && route.length > 0) {
      map.fitBounds(route, { padding: [50, 50] });
    } else if (start && end) {
      map.fitBounds([start, end], { padding: [50, 50] });
    } else if (start) {
      map.setView(start, 13);
    }
  }, [route, start, end, map]);
  return null;
}

export function LiveTracking({ routeState, setRouteState, setActiveTab }: { routeState?: any, setRouteState?: any, setActiveTab?: any }) {
  const [startLoc, setStartLoc] = useState('');
  const [endLoc, setEndLoc] = useState('');
  
  const safeRouteState = routeState || { startCoords: null, endCoords: null, routeLine: [] };
  const { startCoords, endCoords, routeLine } = safeRouteState;

  const updateRouteState = (updates: any) => {
    if (setRouteState) {
      setRouteState((prev: any) => ({ ...prev, ...updates }));
    }
  };

  const setStartCoords = (val: any) => updateRouteState({ startCoords: val });
  const setEndCoords = (val: any) => updateRouteState({ endCoords: val });
  
  const [suggestions, setSuggestions] = useState<any[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [suggestLoading, setSuggestLoading] = useState(false);

  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  
  const setRouteLine = (val: any) => updateRouteState({ routeLine: val });
  const [routeStats, setRouteStats] = useState<{distance: string, time: string} | null>(null);
  const [error, setError] = useState('');

  // Debounce logic for destination suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (endLoc.length < 3) {
        setSuggestions([]);
        return;
      }
      
      setSuggestLoading(true);
      try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(endLoc)}&limit=5`);
        const data = await res.json();
        setSuggestions(data);
      } catch (err) {
        console.error("Failed to fetch suggestions");
      } finally {
        setSuggestLoading(false);
      }
    };

    const timerId = setTimeout(() => {
      if (showSuggestions) fetchSuggestions();
    }, 500);

    return () => clearTimeout(timerId);
  }, [endLoc, showSuggestions]);

  const handleGetCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser.');
      return;
    }

    setLocating(true);
    setError('');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const { latitude, longitude } = position.coords;
          setStartCoords([latitude, longitude]);
          
          const response = await fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`);
          const data = await response.json();
          
          if (data && data.display_name) {
            const addressParts = data.display_name.split(', ');
            const shortAddress = addressParts.length > 3 
              ? `${addressParts[0]}, ${addressParts[1]}, ${addressParts[addressParts.length - 1]}`
              : data.display_name;
            setStartLoc(shortAddress);
          } else {
            setStartLoc(`${latitude.toFixed(4)}, ${longitude.toFixed(4)}`);
          }
        } catch (err) {
          setError('Failed to get location address.');
          setStartLoc(`${position.coords.latitude.toFixed(4)}, ${position.coords.longitude.toFixed(4)}`);
        } finally {
          setLocating(false);
        }
      },
      () => {
        setLocating(false);
        setError("Location access denied or unavailable.");
      },
      { timeout: 10000 }
    );
  };

  const selectSuggestion = (suggestion: any) => {
    setEndLoc(suggestion.display_name);
    setEndCoords([parseFloat(suggestion.lat), parseFloat(suggestion.lon)]);
    setShowSuggestions(false);
  };

  const handleGenerateRoute = async () => {
    if (!startCoords || !endCoords) {
      setError("Please select valid start and end locations");
      return;
    }
    
    setLoading(true);
    setError('');
    
    try {
      // Fast OSRM Public API
      const url = `https://router.project-osrm.org/route/v1/driving/${startCoords[1]},${startCoords[0]};${endCoords[1]},${endCoords[0]}?overview=full&geometries=geojson`;
      const res = await fetch(url);
      const data = await res.json();
      
      if (data.code !== 'Ok') {
        setError("Route could not be calculated.");
        return;
      }
      
      const route = data.routes[0];
      const distKm = (route.distance / 1000).toFixed(2);
      const timeMins = Math.round(route.duration / 60);
      
      // OSRM returns coordinates as [lon, lat] - Leaflet needs [lat, lon]
      const latLngs = route.geometry.coordinates.map((coord: number[]) => [coord[1], coord[0]]);
      
      setRouteLine(latLngs);
      setRouteStats({ distance: `${distKm} km`, time: `${timeMins} mins` });
      
      if (setActiveTab) {
        setActiveTab('overview');
      }
    } catch (err) {
      setError("Failed to generate route");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 min-h-[calc(100vh-160px)]">
      <motion.div 
        initial={{ x: -20, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="glass-card p-6 flex flex-col col-span-1"
      >
        <h3 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
          <MapIcon className="text-cyan-400" />
          Route Navigation
        </h3>

        <div className="space-y-6 flex-1 overflow-y-visible">
          <div>
            <label className="block text-sm font-medium text-white/70 mb-2">Start Location</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className="h-5 w-5 text-emerald-400" />
              </div>
              <input
                type="text"
                value={startLoc}
                onClick={() => {
                  if (!startLoc) handleGetCurrentLocation();
                }}
                onChange={(e) => {
                  setStartLoc(e.target.value);
                  setStartCoords(null);
                }}
                placeholder="Click to use current location"
                className="block w-full pl-10 pr-12 py-3 glass-card bg-white/5 border-white/10 text-white placeholder-white/30 rounded-xl focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
              />
              <button 
                onClick={handleGetCurrentLocation}
                disabled={locating}
                className="absolute inset-y-0 right-0 pr-3 flex items-center text-white/50 hover:text-cyan-400 transition-colors disabled:opacity-50"
                title="Get Current Location"
              >
                {locating ? <Loader2 className="h-5 w-5 animate-spin" /> : <Crosshair className="h-5 w-5" />}
              </button>
            </div>
            {locating && <p className="text-xs text-cyan-400 mt-2">Fetching your location...</p>}
          </div>

          <div className="relative z-50">
            <label className="block text-sm font-medium text-white/70 mb-2">Destination</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Navigation className="h-5 w-5 text-rose-400" />
              </div>
              <input
                type="text"
                value={endLoc}
                onChange={(e) => {
                  setEndLoc(e.target.value);
                  setEndCoords(null);
                  setShowSuggestions(true);
                }}
                onFocus={() => setShowSuggestions(true)}
                placeholder="Type to search nearby..."
                className="block w-full pl-10 pr-10 py-3 glass-card bg-white/5 border-white/10 text-white placeholder-white/30 rounded-xl focus:outline-none focus:border-cyan-500/50 focus:ring-1 focus:ring-cyan-500/50 transition-all"
              />
              {suggestLoading && (
                <div className="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                  <Loader2 className="h-4 w-4 text-cyan-400 animate-spin" />
                </div>
              )}
            </div>

            <AnimatePresence>
              {showSuggestions && suggestions.length > 0 && (
                <motion.ul
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="absolute left-0 right-0 mt-2 bg-[#1e293b] border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 max-h-60 overflow-y-auto"
                >
                  {suggestions.map((s, i) => (
                    <li 
                      key={i}
                      onClick={() => selectSuggestion(s)}
                      className="px-4 py-3 hover:bg-white/10 cursor-pointer border-b border-white/5 last:border-0 flex items-start gap-3 transition-colors"
                    >
                      <Search className="h-4 w-4 text-white/40 mt-1 flex-shrink-0" />
                      <span className="text-sm text-white/80 line-clamp-2">{s.display_name}</span>
                    </li>
                  ))}
                </motion.ul>
              )}
            </AnimatePresence>
          </div>

          <div className="flex flex-col sm:flex-row gap-3 mt-4">
            <button
              onClick={handleGenerateRoute}
              disabled={loading || !startCoords || !endCoords}
              className="flex-1 py-3 rounded-xl bg-cyan-500 text-white font-bold hover:bg-cyan-400 glow-cyan transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? <Loader2 className="animate-spin" /> : "GENERATE ROUTE"}
            </button>
            
            <button
              onClick={() => setLoading(false)}
              disabled={!loading}
              className="px-4 py-3 rounded-xl bg-rose-500/20 text-rose-400 font-bold hover:bg-rose-500/30 border border-rose-500/30 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              title="Cancel Generation"
            >
              <XCircle size={20} />
            </button>

            <button
              onClick={() => {
                setStartLoc('');
                setStartCoords(null);
                setEndLoc('');
                setEndCoords(null);
                setRouteLine([]);
                setRouteStats(null);
                setError('');
              }}
              className="px-4 py-3 rounded-xl bg-white/10 text-white font-bold hover:bg-white/20 border border-white/20 transition-all flex items-center justify-center gap-2"
              title="Reset All"
            >
              <RotateCcw size={20} />
            </button>
          </div>

          {error && <p className="text-rose-400 text-sm mt-2 font-medium bg-rose-500/10 p-2 rounded border border-rose-500/20">{error}</p>}
          
          {routeStats && (
            <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mt-8 p-4 rounded-xl bg-white/5 border border-white/10 glow-cyan">
              <h4 className="text-white font-medium mb-3 flex items-center gap-2">
                <Navigation size={16} className="text-cyan-400" />
                Route Details
              </h4>
              <div className="flex justify-between items-center mb-2">
                <span className="text-white/60 text-sm">Total Distance</span>
                <span className="text-cyan-400 font-bold text-lg">{routeStats.distance}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-white/60 text-sm">Est. Travel Time</span>
                <span className="text-emerald-400 font-bold text-lg">{routeStats.time}</span>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="glass-card col-span-1 lg:col-span-2 relative overflow-hidden rounded-2xl border border-white/10 shadow-2xl min-h-[500px] z-10"
      >
        <MapContainer 
          center={startCoords || [20.5937, 78.9629]} 
          zoom={13} 
          style={{ height: '100%', width: '100%', background: '#0B1220' }}
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          
          {startCoords && (
            <Marker position={startCoords}>
              <Popup>Start Location</Popup>
            </Marker>
          )}
          
          {endCoords && (
            <Marker position={endCoords}>
              <Popup>Destination</Popup>
            </Marker>
          )}

          {routeLine.length > 0 && (
            <Polyline positions={routeLine} color="#06b6d4" weight={5} opacity={0.8} />
          )}

          <MapUpdater route={routeLine} start={startCoords} end={endCoords} />
        </MapContainer>
      </motion.div>
    </div>
  );
}
