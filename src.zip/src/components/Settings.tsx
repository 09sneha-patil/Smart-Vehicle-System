import { useState } from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Volume2, MapPin, Bell, Shield, User } from 'lucide-react';
import { useTheme } from '../ThemeContext';

interface ToggleProps {
  value: boolean;
  onChange: (v: boolean) => void;
}

function Toggle({ value, onChange }: ToggleProps) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative w-12 h-6 rounded-full transition-colors duration-300 focus:outline-none ${
        value ? 'bg-cyan-500' : 'bg-white/20'
      }`}
    >
      <motion.div
        animate={{ x: value ? 24 : 2 }}
        transition={{ type: 'spring', stiffness: 500, damping: 30 }}
        className="absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm"
      />
    </button>
  );
}

export function Settings() {
  const { theme, toggleTheme } = useTheme();
  const isDark = theme === 'dark';

  const [audioAlerts, setAudioAlerts] = useState(true);
  const [locationTracking, setLocationTracking] = useState(true);
  const [notifications, setNotifications] = useState(true);

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl space-y-6">
      <h3 className="text-2xl font-bold text-white">Settings</h3>

      {/* Profile */}
      <div className="glass-card p-6">
        <h4 className="text-sm font-semibold text-white/50 uppercase tracking-wider mb-4 flex items-center gap-2">
          <User size={14} /> Profile
        </h4>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400 font-bold text-xl">
            SP
          </div>
          <div>
            <p className="text-white font-semibold text-lg">Sneha Patil</p>
            <p className="text-white/50 text-sm">Student · SmartDrive Platform</p>
          </div>
        </div>
      </div>

      {/* Appearance */}
      <div className="glass-card p-6">
        <h4 className="text-sm font-semibold text-white/50 uppercase tracking-wider mb-4 flex items-center gap-2">
          {isDark ? <Moon size={14} /> : <Sun size={14} />} Appearance
        </h4>
        <div className="flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-xl">
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${isDark ? 'bg-slate-700' : 'bg-yellow-400/20'}`}>
              {isDark ? <Moon size={18} className="text-slate-300" /> : <Sun size={18} className="text-yellow-400" />}
            </div>
            <div>
              <p className="text-white font-medium">{isDark ? 'Dark Mode' : 'Light Mode'}</p>
              <p className="text-white/50 text-sm">{isDark ? 'Dark interface is currently active' : 'Light interface is currently active'}</p>
            </div>
          </div>
          <Toggle value={isDark} onChange={toggleTheme} />
        </div>

        <div className="mt-3 grid grid-cols-2 gap-3">
          <div
            onClick={() => !isDark && toggleTheme()}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${isDark ? 'border-cyan-500/50 bg-cyan-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}
          >
            <div className="w-full h-8 rounded-lg bg-gray-900 mb-2"></div>
            <div className="flex items-center gap-2">
              <Moon size={14} className={isDark ? 'text-cyan-400' : 'text-white/40'} />
              <span className={`text-sm font-medium ${isDark ? 'text-cyan-400' : 'text-white/60'}`}>Dark</span>
              {isDark && <span className="ml-auto text-[10px] text-cyan-400 border border-cyan-500/30 px-1.5 py-0.5 rounded">Active</span>}
            </div>
          </div>
          <div
            onClick={() => isDark && toggleTheme()}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${!isDark ? 'border-cyan-500/50 bg-cyan-500/10' : 'border-white/10 bg-white/5 hover:bg-white/10'}`}
          >
            <div className="w-full h-8 rounded-lg bg-gray-100 mb-2"></div>
            <div className="flex items-center gap-2">
              <Sun size={14} className={!isDark ? 'text-cyan-400' : 'text-white/40'} />
              <span className={`text-sm font-medium ${!isDark ? 'text-cyan-400' : 'text-white/60'}`}>Light</span>
              {!isDark && <span className="ml-auto text-[10px] text-cyan-400 border border-cyan-500/30 px-1.5 py-0.5 rounded">Active</span>}
            </div>
          </div>
        </div>
      </div>

      {/* Notifications & System */}
      <div className="glass-card p-6">
        <h4 className="text-sm font-semibold text-white/50 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Bell size={14} /> Notifications & System
        </h4>
        <div className="space-y-3">
          {[
            { icon: Volume2, label: 'Audio Alerts', desc: 'Play sounds for critical warnings', value: audioAlerts, onChange: setAudioAlerts },
            { icon: MapPin, label: 'Location Tracking', desc: 'Allow system to access your real-time location', value: locationTracking, onChange: setLocationTracking },
            { icon: Bell, label: 'Push Notifications', desc: 'Receive alert notifications', value: notifications, onChange: setNotifications },
          ].map(({ icon: Icon, label, desc, value, onChange }) => (
            <div key={label} className="flex items-center justify-between p-4 bg-white/5 border border-white/10 rounded-xl">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-white/5">
                  <Icon size={18} className="text-white/60" />
                </div>
                <div>
                  <p className="text-white font-medium">{label}</p>
                  <p className="text-white/50 text-sm">{desc}</p>
                </div>
              </div>
              <Toggle value={value} onChange={onChange} />
            </div>
          ))}
        </div>
      </div>

      {/* System Info */}
      <div className="glass-card p-6">
        <h4 className="text-sm font-semibold text-white/50 uppercase tracking-wider mb-4 flex items-center gap-2">
          <Shield size={14} /> System Info
        </h4>
        <div className="space-y-2 text-sm">
          {[
            ['Platform', 'SmartDrive Vehicle Intelligence'],
            ['Version', 'v2.0.0'],
            ['Backend', 'Python Flask · localhost:5000'],
            ['Frontend', 'React + Vite · localhost:5173'],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-white/5">
              <span className="text-white/50">{k}</span>
              <span className="text-white font-medium">{v}</span>
            </div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}
