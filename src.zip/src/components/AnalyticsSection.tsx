import { motion } from 'framer-motion';
import { 
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, 
  BarChart, Bar, PieChart, Pie, Cell
} from 'recharts';

export function AnalyticsSection({ stats }: { stats?: any }) {
  const currentScore = stats?.score ?? 100;
  const currentAlerts = stats?.alerts ?? 0;
  
  const driverData = [
    { time: '08:00', score: 100, events: 0 },
    { time: '10:00', score: 100, events: 0 },
    { time: '12:00', score: 100, events: 0 },
    { time: '14:00', score: 100, events: 0 },
    { time: '16:00', score: 100, events: 0 },
    { time: 'Now', score: currentScore, events: currentAlerts },
  ];

  const healthData = [
    { name: 'Optimal', value: currentScore > 80 ? 80 : currentScore, color: '#10b981' },
    { name: 'Warning', value: currentScore <= 80 && currentScore > 50 ? 100 - currentScore : 0, color: '#f59e0b' },
    { name: 'Critical', value: currentScore <= 50 ? 100 - currentScore : 0, color: '#ef4444' },
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
      {/* Driver Behaviour Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="glass-card p-6"
      >
        <h3 className="text-lg font-semibold text-white mb-6 flex items-center gap-2">
          Driver Behaviour
          <span className="text-xs font-normal text-white/50 bg-white/5 px-2 py-1 rounded">Today</span>
        </h3>
        
        <div className="h-64 mb-6">
          <p className="text-sm text-white/50 mb-2">Safety Score Trend</p>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={driverData}>
              <XAxis dataKey="time" stroke="#ffffff30" fontSize={12} tickLine={false} axisLine={false} />
              <YAxis domain={[0, 100]} stroke="#ffffff30" fontSize={12} tickLine={false} axisLine={false} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
                itemStyle={{ color: '#06b6d4' }}
              />
              <Line type="monotone" dataKey="score" stroke="#06b6d4" strokeWidth={3} dot={{ fill: '#06b6d4', strokeWidth: 2, r: 4 }} activeDot={{ r: 6, stroke: '#fff' }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="h-32">
          <p className="text-sm text-white/50 mb-2">Driving Events</p>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={driverData}>
              <Tooltip 
                cursor={{ fill: 'rgba(255,255,255,0.05)' }}
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px' }}
              />
              <Bar dataKey="events" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      {/* Vehicle Health Card */}
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="glass-card p-6 flex flex-col"
      >
        <h3 className="text-lg font-semibold text-white mb-6">Vehicle Health</h3>
        
        <div className="flex-1 flex items-center justify-center relative mb-6">
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={healthData}
                innerRadius={70}
                outerRadius={100}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {healthData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ backgroundColor: 'rgba(0,0,0,0.8)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '8px', color: '#fff' }}
                itemStyle={{ color: '#fff' }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-3xl font-bold text-white">{currentScore}%</span>
            <span className="text-xs text-white/50">Fleet Health</span>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-4">
          {healthData.map((item, idx) => (
            <div key={idx} className="bg-white/5 border border-white/10 rounded-xl p-3 flex flex-col items-center justify-center">
              <div className="w-3 h-3 rounded-full mb-2" style={{ backgroundColor: item.color, boxShadow: `0 0 10px ${item.color}50` }}></div>
              <span className="text-white font-medium">{item.value}%</span>
              <span className="text-xs text-white/50">{item.name}</span>
            </div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
