import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  Map, 
  ActivitySquare, 
  Route, 
  AlertTriangle, 
  FileBarChart, 
  Car, 
  Settings,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface MenuItem {
  id: string;
  icon: any;
  label: string;
  badge?: number;
}

const menuItems: MenuItem[] = [
  { id: 'overview', icon: LayoutDashboard, label: 'Overview' },
  { id: 'tracking', icon: Map, label: 'Live Tracking' },
  { id: 'analytics', icon: ActivitySquare, label: 'Driver Analytics' },
  { id: 'trips', icon: Route, label: 'Trips' },
  { id: 'alerts', icon: AlertTriangle, label: 'Alerts' },
  { id: 'reports', icon: FileBarChart, label: 'Reports' },
  { id: 'fleet', icon: Car, label: 'Fleet Management' },
  { id: 'settings', icon: Settings, label: 'Settings' },
];

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  alertCount: number;
}

export function Sidebar({ activeTab, setActiveTab, alertCount }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  const dynamicMenuItems = menuItems.map(item => {
    if (item.id === 'alerts') {
      return { ...item, badge: alertCount > 0 ? alertCount : undefined };
    }
    return item;
  });

  return (
    <motion.aside
      initial={{ x: -20, opacity: 0 }}
      animate={{ x: 0, opacity: 1, width: collapsed ? '80px' : '260px' }}
      className="h-[calc(100vh-80px)] glass-panel border-r border-white/10 flex flex-col relative z-40"
    >
      <button 
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-6 w-6 h-6 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/70 hover:text-white hover:bg-white/20 transition-all z-50 backdrop-blur-md"
      >
        {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
      </button>

      <div className="flex-1 py-6 px-4 flex flex-col gap-2 overflow-y-auto">
        {dynamicMenuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={twMerge(
                "group relative flex items-center gap-4 px-3 py-3 rounded-xl transition-all duration-300 w-full text-left",
                isActive 
                  ? "bg-cyan-500/10 text-cyan-400 glow-cyan border border-cyan-500/20" 
                  : "text-white/50 hover:bg-white/5 hover:text-white border border-transparent"
              )}
            >
              <Icon size={20} className={isActive ? "text-cyan-400" : "text-white/50 group-hover:text-white transition-colors"} />
              
              {!collapsed && (
                <span className="text-sm font-medium whitespace-nowrap">
                  {item.label}
                </span>
              )}

              {item.badge && (
                <span className={clsx(
                  "absolute flex items-center justify-center text-[10px] font-bold bg-rose-500 text-white rounded-full",
                  collapsed ? "top-2 right-2 w-4 h-4" : "right-3 top-1/2 -translate-y-1/2 w-5 h-5 glow-danger"
                )}>
                  {item.badge}
                </span>
              )}

              {collapsed && (
                <div className="absolute left-full ml-4 px-2 py-1 bg-black/80 backdrop-blur-md border border-white/10 rounded-md text-xs text-white opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-opacity">
                  {item.label}
                </div>
              )}
            </button>
          )
        })}
      </div>
    </motion.aside>
  );
}
