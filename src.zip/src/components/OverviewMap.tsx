import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';

// Fix leaflet icon paths
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function MapUpdater({ route, start, end, current }: { route: any, start: any, end: any, current: any }) {
  const map = useMap();
  useEffect(() => {
    if (route && route.length > 0) {
      map.fitBounds(route, { padding: [50, 50] });
    } else if (start && end) {
      map.fitBounds([start, end], { padding: [50, 50] });
    } else if (current) {
      map.setView(current, 13);
    }
  }, [route, start, end, current, map]);
  return null;
}

export function OverviewMap({ currentLocation, routeState }: { currentLocation: [number, number] | null, routeState: any }) {
  const { startCoords, endCoords, routeLine } = routeState;
  
  // Center is either current location, start coords, or default to India
  const center = currentLocation || startCoords || [20.5937, 78.9629];

  return (
    <div className="w-full h-full relative group">
      {/* If no location and no route, maybe show a small overlay text */}
      {!currentLocation && !startCoords && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[1000] bg-black/80 text-white/70 text-xs px-4 py-2 rounded-full border border-white/10 backdrop-blur-md">
          Location unavailable
        </div>
      )}
      
      <MapContainer 
        center={center as [number, number]} 
        zoom={13} 
        style={{ height: '100%', width: '100%', background: '#0B1220' }}
        zoomControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
        />
        
        {currentLocation && (
          <Marker position={currentLocation}>
            <Popup>Your Current Location</Popup>
          </Marker>
        )}

        {startCoords && startCoords !== currentLocation && (
          <Marker position={startCoords}>
            <Popup>Start Location</Popup>
          </Marker>
        )}
        
        {endCoords && (
          <Marker position={endCoords}>
            <Popup>Destination</Popup>
          </Marker>
        )}

        {routeLine && routeLine.length > 0 && (
          <Polyline positions={routeLine} color="#06b6d4" weight={5} opacity={0.8} />
        )}

        <MapUpdater route={routeLine} start={startCoords} end={endCoords} current={currentLocation} />
      </MapContainer>
    </div>
  );
}
